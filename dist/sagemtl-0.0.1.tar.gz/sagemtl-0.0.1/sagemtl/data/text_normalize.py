﻿from __future__ import annotations
import warnings
from sagemtl.clean.text_normalize import normalize_text, basic_clean

warnings.warn(
    "sagemtl.data.text_normalize is deprecated. Use sagemtl.clean.text_normalize instead.",
    DeprecationWarning,
    stacklevel=2,
)
__all__ = ["normalize_text", "basic_clean"]
