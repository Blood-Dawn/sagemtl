# sagemtl
Blood-Dawn — starter repo for the SageMTL toolchain (docs, crawler, ML).

## Goals
- MTL pipeline experiments (crawler + cleaning + models)
- Reproducible envs (.venv-ml, .venv-doc, .venv-crawl)

