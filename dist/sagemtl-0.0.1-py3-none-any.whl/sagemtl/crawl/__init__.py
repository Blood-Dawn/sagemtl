﻿from .extract import extract_main_text
from .http import fetch_text

__all__ = ["fetch_text", "extract_main_text"]
